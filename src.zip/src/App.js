import Home from './routs';
import '../src/sass/global.scss';
function App() {
  return (
   <Home/>
  );
}

export default App;
