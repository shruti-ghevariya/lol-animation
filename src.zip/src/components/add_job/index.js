import React from 'react'
import './addjob.scss';
import cupImage from '../../assets/images/cup-img.png';
import fullRound from '../../assets/images/full-round.png';

export default function AddJob() {
    return (
        <div className='add-job'>
            <div className="container">
                <div className="text-grid">
                    <h1>The only job that adds years to your life</h1>
                    <div className="child-text-center">
                        <p>Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet. Amet minim mollit non deserunt veniam consequat sunt nostrud amet.</p>
                    </div>
                </div>
                <div className="relative-section">
                    <div className="cup-image">
                        <img src={cupImage} alt="" />
                    </div>

                    <div className="full-round">
                        <img src={fullRound} alt="" />
                    </div>
                    <div className="add-job-image-alignment">
                        .add-job-img
                    </div>
                </div>

            </div>
        </div>
    )
}
